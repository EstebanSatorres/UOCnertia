package edu.uoc.nertia.model.stack;

import java.util.*;

public class UndoStack extends Stack<StackItem> {

    private int numPops = 0;

    public int getNumPops() {
        return numPops;
    }

    private void incrementNumPops() {
        numPops++;
    }

    @Override
    public StackItem pop() {
        if(!isEmpty()) {
            incrementNumPops();
            return super.pop();
        }
        return null;
    }
}
