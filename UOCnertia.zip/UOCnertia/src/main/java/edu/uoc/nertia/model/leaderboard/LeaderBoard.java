package edu.uoc.nertia.model.leaderboard;

import edu.uoc.nertia.model.stack.StackItem;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author Esteban Satorres
 * @version 1.0
 */
public class LeaderBoard{

    /**
     * Maximum scores that will be stored.
     */
    private final int maxScores;

    /**
     * List with the top highest scores.
     */
    private List<Score> scores;

    /**
     * Name of the file where the data will be stored.
     */
    private static final String FILE_LEADERBOARD = "leaderboard.ser";



    private List<Score> getScores(){
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(FILE_LEADERBOARD))){
            return (List<Score>) input.readObject();
        } catch (IOException | ClassNotFoundException e) {
            return new ArrayList<>(this.getMaxScores());
        }
    }

    public void add(String name, int points){
        this.scores = getScores();
        //Checks if the points that are passed as a parameter can be included in the leaderboard.
        if(isInTheTop(points)){
            //Add the new score (i.e. player's name and points) in the scores list.
          scores.add(new Score(name,points));
          Collections.sort(scores);
            //The scores list must be sorted in descendant order, i.e. being the first score the one that has the highest points
          scores = new ArrayList<>(scores.subList(0, scores.size()<maxScores?scores.size():maxScores));
        }

        //DONE: write to the file. DON'T MODIFY
        try(ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(FILE_LEADERBOARD,false))){
            output.writeObject(scores);
        } catch (NotSerializableException e) {
            System.out.println("||1|"+e.getMessage());
        } catch (InvalidClassException  e) {
            System.out.println("||2|"+e.getMessage());
        } catch (IOException  e) {
            System.out.println("||3|"+e.getMessage());
        }
    }

    /**
     * Returns if the given points deserve to be in the top list.
     * @param points Score to compare
     * @return {@code true} if the given points deserve to be in the leaderboard. Otherwise, {@code false}.
     */
    public boolean isInTheTop(int points){

       //Option 1
//        this.scores = getScores();
//                List<Score> d = scores.stream()
//                        //.sorted(Comparator.comparing(Score::points).reversed())
//                        //.limit(getMaxScores())
//                        .filter(score -> score.points() < points)
//                        .toList();
//        return scores.isEmpty() || scores.size() < getMaxScores() || !d.isEmpty();

        //Option 2 - more clear and tidy
        scores = getScores();
        return scores==null || scores.size() < maxScores || scores.stream().anyMatch(s -> s.points() < points);
    }

    /** Constructor for LeaderBoard
     * @param maxScores Number of scores that must be stored. If {@code maxsScores}
     *                  is negative or zero, then the default value is 5.
     */
    public LeaderBoard(int maxScores) {
        if(maxScores <= 0) {
            this.maxScores = 5;
        } else{
            this.maxScores = maxScores;
        }
    }

    /**
     * Returns the value of the attribute {@code MAX_SCORES}.
     * @return The value of {@code MAX_SCORES}.
     */
    public int getMaxScores(){
        return maxScores;
    }

    /** Returns the top five high scores, in order from best to worst
     * @return String with the top five high scores.
     */
    @Override
    public String toString() {
         List<String> list = scores.stream()
                .sorted(Comparator.comparing(Score::points).reversed())
                .limit(getMaxScores())
                .map(Score::toString).toList();

        StringBuilder aux = new StringBuilder();
        var i = 1;
        for (String item : list) {
            aux.append(i).append(") ").append(item).append("\r\n");
            i++;
        }
        return aux.toString();
    }
}
