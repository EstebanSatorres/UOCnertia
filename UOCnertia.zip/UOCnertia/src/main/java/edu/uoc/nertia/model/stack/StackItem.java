package edu.uoc.nertia.model.stack;

import edu.uoc.nertia.model.cells.Element;
import edu.uoc.nertia.model.utils.Position;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public record StackItem(Position originPosition, Element originElement, List<Position> collectedLives, List<Position> collectedGems) {

//    @Override
//    public boolean equals(Object o) {
//        if (this == o) return true;
//        if (o == null || getClass() != o.getClass()) return false;
//        StackItem stackItem = (StackItem) o;
//        return Objects.equals(originPosition, stackItem.originPosition) && originElement == stackItem.originElement && Objects.equals(collectedLives, stackItem.collectedLives) && Objects.equals(collectedGems, stackItem.collectedGems);
//    }
//
//    @Override
//    public int hashCode() {
//        return Objects.hash(originPosition, originElement, collectedLives, collectedGems);
//    }
//
//    @Override
//    public String toString() {
//        return "StackItem{" +
//                "originPosition=" + originPosition +
//                ", originElement=" + originElement +
//                ", collectedLives=" + collectedLives +
//                ", collectedGems=" + collectedGems +
//                '}';
//    }
}
