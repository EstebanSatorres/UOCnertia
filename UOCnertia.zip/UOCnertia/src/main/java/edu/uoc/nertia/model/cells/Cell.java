package edu.uoc.nertia.model.cells;

import edu.uoc.nertia.model.utils.Position;

public class Cell {
    private Element element;
    private Position position;

    public Cell(Position position, Element element) {
        setPosition(position);
        setElement(element);
    }

    public final Position getPosition() {
        return position;
    }

    public final Element getElement() {
            return element;
    }

    private void setPosition(Position position) {
        this.position = position;
    }

    public void setElement(Element element) {
        this.element = element;
    }

    @Override
    public String toString() {
        //First Option
//        if(getElement() == null) {
//            return " ";
//        } else {
//            return String.valueOf(element.getSymbol());
//        }
        //Second Option
        return element != null ? element.toString(): "";


    }
}
