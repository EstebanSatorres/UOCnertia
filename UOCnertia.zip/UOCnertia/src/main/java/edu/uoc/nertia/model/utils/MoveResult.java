package edu.uoc.nertia.model.utils;

public enum MoveResult {
    OK,
    KO,
    DIE;
}
