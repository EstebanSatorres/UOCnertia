package edu.uoc.nertia.model.utils;

import edu.uoc.nertia.model.exceptions.PositionException;

import java.util.Objects;

public class Position {
    private int row;
    private int column;

    public Position(int row, int column) throws PositionException {
        setRow(row);
        setColumn(column);
    }

    public int getRow() {
        return row;
    }

    private void setRow(int row) throws PositionException {
        if(row<0) {
            throw new PositionException(PositionException.POSITION_ROW_ERROR);
        }
        this.row = row;
    }

    public int getColumn() {
        return column;
    }

    private void setColumn(int column) throws PositionException {
        if(column<0) {
            throw new PositionException(PositionException.POSITION_COLUMN_ERROR);
        }
        this.column = column;
    }

    public Position offsetBy(final int dRow, final int dColumn) {
        try {
            return new Position(getRow() + dRow, getColumn() + dColumn);
        } catch (PositionException e) {
            return null;
        }
    }

    public Position offsetBy(final int dRow, final int dColumn, final int size) {
        if(size <= 0 ||getRow() + dRow >= size || getColumn() + dColumn >= size) {
            return null;
        }
        return offsetBy(dRow, dColumn);
    }

    @Override
    public int hashCode() {
        return Objects.hash(row, column);
    }

    @Override
    public boolean equals(Object o) {
        //First Option
//        if (getClass() != o.getClass()) return false;
//        return this.getRow() == ((Position) o).getRow() && this.getColumn() == ((Position) o).getColumn();
        //Second Option
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Position position = (Position) o;
        return row == position.row && column == position.column;
    }
}
