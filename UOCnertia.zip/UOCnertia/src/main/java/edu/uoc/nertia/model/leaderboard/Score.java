package edu.uoc.nertia.model.leaderboard;

import java.io.Serial;
import java.io.Serializable;
import java.util.Locale;
import java.util.Objects;

public record Score(String name, int points) implements Comparable<Score>, Serializable{

    private static final long serialVersionUID = 13L;

//    @Override
//    public boolean equals(Object o) {
//        if (this == o) return true;
//        if (o == null || getClass() != o.getClass()) return false;
//        Score score = (Score) o;
//        return points == score.points && Objects.equals(name, score.name);
//    }
//
//    @Override
//    public int hashCode() {
//        return Objects.hash(name, points);
//    }

    @Override
    public String toString() {
        return name.toUpperCase()+" : "+points+" pts";
    }

    @Override
    public int compareTo(Score o) {  //No lo tengo claro
        return o.points() - this.points;
    }
}
