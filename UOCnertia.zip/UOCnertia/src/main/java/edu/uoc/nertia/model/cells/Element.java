package edu.uoc.nertia.model.cells;

public enum Element {
    EMPTY('-', "empty.png"),
    EXTRA_LIFE('L', "life.png"),
    GEM('*', "gem.png"),
    MINE('X', "mine.png"),
    PLAYER('@',"player.png"),
    STOP('S',"stop.png"),
    PLAYER_STOP('$',"player_stop.png"),
    WALL('#',"wall.png");

    private char symbol;
    private String imageSrc;

    Element(char symbol, String imageSrc) {
        setSymbol(symbol);
        setImageSrc(imageSrc);
    }

    public char getSymbol() {
        return symbol;
    }

    private void setSymbol(char symbol) {
        this.symbol = symbol;
    }

    public String getImageSrc() {
        return imageSrc;
    }

    private void setImageSrc(String imageSrc) {
        this.imageSrc = imageSrc;
    }

    public static Element symbol2Element(char symbol) {
        for(var value : Element.values()) {
            if(value.getSymbol() == symbol) {
                return value;
            }
        } return null;
    }

    @Override
    public String toString() {
        //return String.valueOf(this.getSymbol());
        return Character.toString(symbol);
    }

}
